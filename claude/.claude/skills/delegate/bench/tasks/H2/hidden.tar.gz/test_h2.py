import io
import os
import tempfile
import unittest
from contextlib import redirect_stdout

from ledger.cli import main
from ledger.parser import parse_csv
from ledger.report import totals_by_month

H = "date,account,amount,memo\n"
CSV = H + ("2026-02-10,food,3.00,\n2026-01-05,rent,800,\n2026-01-03,food,12.50,\n"
           "2026-02-01,bike,40,\n2026-01-20,food,1.25,\n")


def run(*args):
    with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False) as fh:
        fh.write(CSV)
    out = io.StringIO()
    try:
        with redirect_stdout(out):
            rc = main([fh.name, *args])
    finally:
        os.unlink(fh.name)
    return rc, out.getvalue()


class H2(unittest.TestCase):
    def test_totals_by_month(self):
        r = totals_by_month(parse_csv(CSV))
        self.assertEqual(sorted(r), ["2026-01", "2026-02"])
        self.assertEqual({k: float(v) for k, v in r["2026-01"].items()}, {"food": 13.75, "rent": 800.0})
        self.assertEqual({k: float(v) for k, v in r["2026-02"].items()}, {"bike": 40.0, "food": 3.0})

    def test_cli_by_month(self):
        rc, out = run("--by-month")
        self.assertEqual(rc, 0)
        self.assertEqual(out, "== 2026-01 ==\nfood: 13.75\nrent: 800.00\n== 2026-02 ==\nbike: 40.00\nfood: 3.00\n")

    def test_cli_by_month_account(self):
        rc, out = run("--by-month", "--account", "food")
        self.assertEqual(out, "== 2026-01 ==\nfood: 13.75\n== 2026-02 ==\nfood: 3.00\n")

    def test_cli_by_month_account_absent_month(self):
        rc, out = run("--by-month", "--account", "rent")
        self.assertEqual(out, "== 2026-01 ==\nrent: 800.00\n")

    def test_default_unchanged(self):
        rc, out = run()
        self.assertEqual(out, "bike: 40.00\nfood: 16.75\nrent: 800.00\n")

    def test_bad_date(self):
        for bad in ("2026/01/05", "26-01-05", "2026-1-5", "x"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                totals_by_month(parse_csv(H + f"{bad},a,1,\n"))
