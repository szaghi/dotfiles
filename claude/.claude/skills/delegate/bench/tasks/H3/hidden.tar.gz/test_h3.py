import dataclasses
import pathlib
import re
import unittest
import warnings

from ledger.model import Transaction
from ledger.parser import parse_csv
from ledger.report import format_report, totals_by_account

CSV = "date,account,amount,memo\n2026-01-03,food,12.50,lunch\n2026-01-04,rent,800,\n"


class H3(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("error", DeprecationWarning)
        self.addCleanup(warnings.resetwarnings)

    def test_is_dataclass_with_new_field(self):
        self.assertTrue(dataclasses.is_dataclass(Transaction))
        names = [f.name for f in dataclasses.fields(Transaction)]
        self.assertEqual(names, ["date", "account", "amount", "memo"])

    def test_positional_and_defaults(self):
        tx = Transaction("2026-01-01", "a", 5)
        self.assertEqual((tx.amount, tx.memo), (5, ""))
        self.assertEqual(Transaction("2026-01-01", "a", 5, "m").memo, "m")

    def test_new_keyword_no_warning(self):
        self.assertEqual(Transaction(date="d", account="a", amount=5).amount, 5)

    def test_eq_repr(self):
        self.assertEqual(Transaction("d", "a", 1), Transaction("d", "a", 1))
        self.assertIn("amount=1", repr(Transaction("d", "a", 1)))
        self.assertNotIn("amt=", repr(Transaction("d", "a", 1)))

    def test_amt_read_warns(self):
        tx = Transaction("d", "a", 3)
        with self.assertWarns(DeprecationWarning):
            self.assertEqual(tx.amt, 3)

    def test_amt_write_warns(self):
        tx = Transaction("d", "a", 3)
        with self.assertWarns(DeprecationWarning):
            tx.amt = 7
        self.assertEqual(tx.amount, 7)

    def test_amt_keyword_warns(self):
        with self.assertWarns(DeprecationWarning):
            tx = Transaction(date="d", account="a", amt=9)
        self.assertEqual(tx.amount, 9)

    def test_both_keywords_type_error(self):
        with self.assertRaises(TypeError):
            Transaction(date="d", account="a", amount=1, amt=2)

    def test_package_uses_new_name(self):
        txs = parse_csv(CSV)
        self.assertEqual(float(txs[0].amount), 12.5)
        self.assertEqual(format_report(totals_by_account(txs)), "food: 12.50\nrent: 800.00")

    def test_no_old_name_outside_model(self):
        for py in pathlib.Path("ledger").glob("*.py"):
            if py.name == "model.py":
                continue
            with self.subTest(file=py.name):
                self.assertIsNone(re.search(r"\.amt\b|\bamt\s*=", py.read_text()))
