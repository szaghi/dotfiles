import unittest
from decimal import Decimal

from ledger.parser import parse_csv
from ledger.report import format_report, totals_by_account

H = "date,account,amount,memo\n"


def rep(rows):
    return format_report(totals_by_account(parse_csv(H + rows)))


class H1(unittest.TestCase):
    def test_no_drift(self):
        self.assertEqual(rep("2026-01-01,a,0.1,\n2026-01-02,a,0.2,\n"), "a: 0.30")

    def test_many_tenths(self):
        self.assertEqual(rep("".join("2026-01-01,a,0.1,\n" for _ in range(10))), "a: 1.00")

    def test_half_up(self):
        self.assertEqual(rep("2026-01-01,a,1.005,\n"), "a: 1.01")

    def test_half_up_negative(self):
        self.assertEqual(rep("2026-01-01,a,-0.125,\n"), "a: -0.13")

    def test_half_up_sum(self):
        self.assertEqual(rep("2026-01-01,a,0.0025,\n2026-01-01,a,0.0025,\n"), "a: 0.01")

    def test_totals_exact_decimal(self):
        t = totals_by_account(parse_csv(H + "2026-01-01,a,0.1,\n2026-01-01,a,0.2,\n"))
        self.assertIsInstance(t["a"], Decimal)
        self.assertEqual(t["a"], Decimal("0.3"))

    def test_amount_decimal(self):
        self.assertIsInstance(parse_csv(H + "2026-01-01,a,2.50,\n")[0].amt, Decimal)

    def test_format_unchanged(self):
        self.assertEqual(rep("2026-01-03,food,12.50,x\n2026-01-04,rent,800,\n2026-01-05,bike,0,\n"),
                         "bike: 0.00\nfood: 12.50\nrent: 800.00")
